# JADWAL — Production Deployment Guide
## Thomas Tamrat Goshu | JADWAL Technologies LLC | Dubai, UAE

---

## THE STACK (Best for UAE SaaS, non-technical founder)

| Layer | Service | Why | Monthly Cost |
|-------|---------|-----|-------------|
| **Backend API** | Railway | FastAPI, one-click deploy, free tier, auto HTTPS | Free → $5/mo |
| **Database + Auth + Storage** | Supabase | PostgreSQL + auth + file storage in one | Free → $25/mo |
| **Frontend** | Vercel | React/Next.js, free tier, instant deploys | Free |
| **Email** | Resend | Best deliverability, simple API | Free → $20/mo |
| **Payments UAE** | Ziina | UAE local payment, AED payments | % per txn |
| **Payments Global** | PayPal | International cards, well-known | % per txn |
| **WhatsApp** | 360Dialog | WhatsApp Business API | ~$50/mo |
| **Domain** | Namecheap / GoDaddy | jadwal.ae | ~AED 150/year |

**Total to go live: ~$80/month (AED 300)**

---

## STEP 1 — SUPABASE SETUP (15 minutes)

1. Go to **supabase.com** → Create new project
2. Choose region: **Singapore** (closest to UAE with good latency)
3. Name it: `jadwal-production`
4. Save your database password somewhere safe

5. In Supabase Dashboard → **SQL Editor** → New Query
6. Paste the entire contents of `migrations/001_schema.sql`
7. Click Run — all tables, indexes, and policies are created

8. Go to **Settings → API**
9. Copy: `Project URL`, `anon key`, `service_role key`
10. Copy database connection string from **Settings → Database**

11. Go to **Storage** → Create bucket named `jadwal-documents`
12. Set bucket to **private** (documents are confidential)

---

## STEP 2 — RAILWAY BACKEND DEPLOYMENT (10 minutes)

1. Go to **railway.app** → Sign up with GitHub
2. Click **New Project → Deploy from GitHub repo**
3. Connect your GitHub and select the `jadwal_backend` repo

4. Railway auto-detects Python → it will try to run `uvicorn app.main:app`
5. Add a `Procfile` to the root:
   ```
   web: uvicorn app.main:app --host 0.0.0.0 --port $PORT
   ```

6. Go to **Variables** tab in Railway → Add all your environment variables
   (copy from .env.example, fill in real values)

7. Click **Deploy** — Railway builds and deploys automatically
8. Copy your Railway URL: `https://jadwal-backend-xxxx.railway.app`

9. Test: visit `https://your-railway-url.railway.app/health`
   → Should return `{"status": "healthy"}`

---

## STEP 3 — ENVIRONMENT VARIABLES ON RAILWAY

In Railway dashboard → your service → Variables tab, add:

```
ENVIRONMENT=production
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_KEY=eyJ...
DATABASE_URL=postgresql://postgres:...
JWT_SECRET=<generate with: python -c "import secrets; print(secrets.token_hex(32))">
ANTHROPIC_API_KEY=sk-ant-...
RESEND_API_KEY=re_...
PAYPAL_CLIENT_ID=...
PAYPAL_CLIENT_SECRET=...
PAYPAL_MODE=live
ZIINA_API_KEY=...
ZIINA_WEBHOOK_SECRET=...
DIALOG360_API_KEY=...
FRONTEND_URL=https://jadwal.ae
ALLOWED_ORIGINS=["https://jadwal.ae","https://app.jadwal.ae"]
```

---

## STEP 4 — VERCEL FRONTEND DEPLOYMENT (5 minutes)

1. Go to **vercel.com** → New Project
2. Import your frontend repo (the React/Next.js app)
3. Add environment variable:
   ```
   NEXT_PUBLIC_API_URL=https://your-railway-url.railway.app
   ```
4. Deploy → Vercel gives you `https://jadwal.vercel.app`
5. Go to Vercel → Settings → Domains → Add `jadwal.ae`

---

## STEP 5 — DOMAIN SETUP

1. Buy `jadwal.ae` from **ae.godaddy.com** or **namecheap.com**
   (.ae domains require Emirates ID — use your UAE trade license)

2. In your domain DNS settings, add:
   ```
   A record:   @      → Vercel IP (shown in Vercel dashboard)
   CNAME:      www    → cname.vercel-dns.com
   CNAME:      api    → your-railway-url.railway.app
   ```

3. Vercel and Railway handle SSL certificates automatically (HTTPS)

---

## STEP 6 — PAYPAL SETUP

1. Go to **developer.paypal.com** → Create App
2. Name: `JADWAL`
3. Copy: Client ID + Client Secret → Add to Railway env vars
4. Set up webhook in PayPal dashboard:
   - URL: `https://api.jadwal.ae/api/webhooks/paypal-webhook`
   - Events: `PAYMENT.CAPTURE.COMPLETED`, `BILLING.SUBSCRIPTION.CANCELLED`
5. Copy Webhook ID → Add to Railway as `PAYPAL_WEBHOOK_ID`
6. Change `PAYPAL_MODE=live` when ready for real payments

---

## STEP 7 — ZIINA SETUP (UAE Payments)

1. Go to **business.ziina.com** → Create business account
2. Complete UAE business verification (trade license required)
3. Get API key → Add to Railway
4. Set webhook URL: `https://api.jadwal.ae/api/webhooks/ziina-webhook`
5. Copy webhook secret → Add to Railway as `ZIINA_WEBHOOK_SECRET`

---

## STEP 8 — RESEND EMAIL SETUP (5 minutes)

1. Go to **resend.com** → Create account
2. Add domain: `jadwal.ae`
3. Add DNS records (Resend shows you exactly which ones)
4. Create API key → Add to Railway as `RESEND_API_KEY`
5. Test: `POST /api/auth/signup` → welcome email should arrive

---

## STEP 9 — 360DIALOG WHATSAPP SETUP

1. Go to **client.360dialog.com**
2. Connect your WhatsApp Business number (+971 55 466 0881)
3. Complete Meta Business verification (takes 1-3 days)
4. Get API key → Add to Railway as `DIALOG360_API_KEY`

---

## STEP 10 — SUPABASE STORAGE BUCKET POLICY

Run this in Supabase SQL Editor to allow your server to access files:

```sql
-- Allow service role full access (your backend uses service key)
CREATE POLICY "service_full_access" ON storage.objects
  USING (auth.role() = 'service_role');

-- Prevent direct public access (all downloads via signed URLs)
CREATE POLICY "no_public_access" ON storage.objects
  FOR SELECT USING (false);
```

---

## API ENDPOINTS SUMMARY

```
POST   /api/auth/signup                → Create account
POST   /api/auth/login                 → Login, get JWT
GET    /api/auth/me                    → Current user

GET    /api/employees                  → List employees
POST   /api/employees                  → Add employee
PUT    /api/employees/{id}             → Update employee
DELETE /api/employees/{id}             → Remove employee

POST   /api/schedule/generate          → AI generates schedule
POST   /api/schedule/{id}/publish      → Publish schedule
POST   /api/schedule/{id}/send-whatsapp → Send WA notifications
GET    /api/schedule/list              → All schedules

POST   /api/files/upload/{emp_id}/{type}   → Upload document
GET    /api/files/{emp_id}/{type}/url      → Get signed URL
DELETE /api/files/{doc_id}                 → Delete document

GET    /api/compliance/emiratisation   → Live compliance data
GET    /api/compliance/wps             → WPS file data
GET    /api/hr/employees/{id}          → HR profile

POST   /api/payments/paypal/create-order   → PayPal order
POST   /api/payments/paypal/capture        → Capture payment
POST   /api/payments/ziina/create          → Ziina payment
GET    /api/payments/status                → Subscription status

POST   /api/webhooks/paypal-webhook    → PayPal events
POST   /api/webhooks/ziina-webhook     → Ziina events
```

---

## SECURITY CHECKLIST BEFORE GO-LIVE

- [ ] JWT_SECRET is at least 32 random characters
- [ ] SUPABASE_SERVICE_KEY is only in Railway env vars (never in frontend)
- [ ] ANTHROPIC_API_KEY is only in Railway env vars (never in browser)
- [ ] Row Level Security enabled on all Supabase tables (done in schema)
- [ ] CORS allows only jadwal.ae domains
- [ ] PAYPAL_MODE=live (not sandbox)
- [ ] All webhook URLs use HTTPS
- [ ] .env file is in .gitignore

---

## ESTIMATED COSTS AT 200 CUSTOMERS

| Service | Cost |
|---------|------|
| Railway (backend) | $5/month |
| Supabase (Pro) | $25/month |
| Vercel (Pro) | $20/month |
| Resend | $20/month |
| 360Dialog WhatsApp | ~$50/month |
| **Total infrastructure** | **~$120/month (AED 440)** |
| **Revenue at 200 customers** | **AED 59,800/month** |
| **Profit margin** | **99.3%** |

---

## SUPPORT

Thomas Tamrat Goshu · Founder  
+971 55 466 0881 · thomas@jadwal.ae  
JADWAL Technologies LLC · Meydan Free Zone, Dubai, UAE
