"""
JADWAL — AI Schedule Routes
The Anthropic API key NEVER leaves the server.
The browser calls /api/schedule/generate — our server calls Anthropic.

POST /api/schedule/generate
POST /api/schedule/publish
POST /api/schedule/send-whatsapp
GET  /api/schedule/list
GET  /api/schedule/{schedule_id}
"""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, date
import anthropic
import json
import time
import uuid
import logging

from app.config import settings
from app.database import get_db
from app.routes.auth import get_current_user
from app.services.whatsapp_service import send_whatsapp
from app.services.audit_service import log_action

router = APIRouter()
logger = logging.getLogger(__name__)

# Anthropic client — created once on server startup, key never leaves server
anthropic_client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)


# ── SCHEMAS ───────────────────────────────────────────────────────────────────
class GenerateRequest(BaseModel):
    business_type: str = "Retail Store"
    week_start: Optional[str] = None   # ISO date string


# ── GENERATE SCHEDULE ─────────────────────────────────────────────────────────
@router.post("/generate")
async def generate_schedule(
    body: GenerateRequest,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    business_id = uuid.UUID(current_user["business_id"])

    # Load active employees
    employees = await db.fetch(
        """SELECT id, name, role, nationality, max_hours_week,
                  visa_expiry, permit_expiry, documents, hr_status
           FROM employees
           WHERE business_id = $1 AND active = TRUE
           ORDER BY name""",
        business_id
    )
    if not employees:
        raise HTTPException(status_code=400, detail="No active employees found")

    emps = [dict(e) for e in employees]

    # Identify HR issues — schedule generates regardless, just noted
    hr_alerts = []
    for emp in emps:
        issues = []
        docs = emp.get("documents") or {}
        if isinstance(docs, str):
            docs = json.loads(docs)

        if not docs.get("passport"):       issues.append("missing passport")
        if not docs.get("visa_copy"):      issues.append("missing visa copy")
        if not docs.get("employment_contract"): issues.append("missing contract")

        if emp.get("permit_expiry"):
            pd = (datetime.strptime(str(emp["permit_expiry"]), "%Y-%m-%d").date() - date.today()).days
            if pd < 0:
                issues.append(f"permit expired {abs(pd)} days ago")

        if issues:
            hr_alerts.append({"employee": emp["name"], "issues": issues})

    # Check if it's summer (midday break law)
    is_summer = datetime.now().month in [6, 7, 8, 9]

    # ── BUILD PROMPT ──────────────────────────────────────────────────────────
    emp_list = "\n".join([
        f"- {e['name']} | {e['role']} | {e['nationality']} | Max {e['max_hours_week']}hrs/week"
        for e in emps
    ])

    prompt = f"""You are a UAE workforce scheduling AI for a {body.business_type}.

Employees:
{emp_list}

UAE Labor Law Rules:
- Maximum 8 hours per shift
- Maximum 5 working days per week (48hrs max)
- At least 1 Supervisor or Team Lead scheduled every day
- Friday is a short day (Morning 7AM-12PM only if scheduled)
- Prioritize Emirati staff on customer-facing shifts (Emiratisation)
{"- MIDDAY BREAK LAW ACTIVE: No outdoor roles (Security, Cleaning, Warehouse, Driver) can work 12:30PM-3:00PM (UAE Article 66, June-September)" if is_summer else ""}

Return ONLY valid JSON array, no markdown, no extra text:
[
  {{
    "employee": "Full Name",
    "role": "Role",
    "emirati": true,
    "schedule": {{
      "Sunday": "Morning 7AM-3PM or Afternoon 3PM-11PM or OFF",
      "Monday": "...",
      "Tuesday": "...",
      "Wednesday": "...",
      "Thursday": "...",
      "Friday": "Morning 7AM-12PM or OFF"
    }},
    "total_hours": 40,
    "whatsapp_msg": "Friendly personalized WhatsApp message in English mentioning their specific shifts. Sign as JADWAL."
  }}
]"""

    # ── CALL ANTHROPIC (server-side only) ─────────────────────────────────────
    start_ms = int(time.time() * 1000)
    try:
        message = anthropic_client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1500,
            messages=[{"role": "user", "content": prompt}]
        )
        raw = message.content[0].text.strip()
        # Clean any accidental markdown
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        schedule_data = json.loads(raw.strip())
    except json.JSONDecodeError as e:
        logger.error(f"Schedule JSON parse error: {e}")
        raise HTTPException(status_code=500, detail="AI returned invalid schedule format")
    except anthropic.APIError as e:
        logger.error(f"Anthropic API error: {e}")
        raise HTTPException(status_code=503, detail="AI service temporarily unavailable")

    generation_ms = int(time.time() * 1000) - start_ms

    # ── SAVE TO DATABASE ──────────────────────────────────────────────────────
    schedule_id = uuid.uuid4()
    week_start = body.week_start or date.today().isoformat()

    await db.execute(
        """INSERT INTO schedules
           (id, business_id, created_by, week_start, business_type,
            schedule_data, hr_alerts, ai_model, generation_ms)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)""",
        schedule_id,
        business_id,
        uuid.UUID(current_user["id"]),
        week_start,
        body.business_type,
        json.dumps(schedule_data),
        json.dumps(hr_alerts),
        "claude-sonnet-4-20250514",
        generation_ms
    )

    # Save individual shifts
    for row in schedule_data:
        emp = next((e for e in emps if e["name"] == row["employee"]), None)
        if not emp:
            continue
        for day, shift in row.get("schedule", {}).items():
            is_off = shift == "OFF" or not shift
            await db.execute(
                """INSERT INTO shifts (schedule_id, employee_id, business_id,
                   shift_date, shift_type, is_off, hours)
                   VALUES ($1, $2, $3, $4, $5, $6, $7)""",
                schedule_id,
                uuid.UUID(str(emp["id"])),
                business_id,
                week_start,   # simplified — would calculate actual date per day
                shift if not is_off else None,
                is_off,
                row.get("total_hours", 40) / 5 if not is_off else 0
            )

    await log_action(db, business_id, uuid.UUID(current_user["id"]),
                     "schedule.generated", "schedule", schedule_id,
                     {"employees": len(emps), "hr_alerts": len(hr_alerts)})

    return {
        "schedule_id": str(schedule_id),
        "schedule_data": schedule_data,
        "hr_alerts": hr_alerts,       # Always returned — never blocks
        "generation_ms": generation_ms,
        "week_start": week_start,
        "employee_count": len(emps),
    }


# ── PUBLISH ───────────────────────────────────────────────────────────────────
@router.post("/{schedule_id}/publish")
async def publish_schedule(
    schedule_id: str,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    await db.execute(
        """UPDATE schedules SET published = TRUE, published_at = NOW()
           WHERE id = $1 AND business_id = $2""",
        uuid.UUID(schedule_id), uuid.UUID(current_user["business_id"])
    )
    await log_action(db, uuid.UUID(current_user["business_id"]),
                     uuid.UUID(current_user["id"]),
                     "schedule.published", "schedule", uuid.UUID(schedule_id))
    return {"message": "Schedule published"}


# ── SEND WHATSAPP ─────────────────────────────────────────────────────────────
@router.post("/{schedule_id}/send-whatsapp")
async def send_schedule_whatsapp(
    schedule_id: str,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    schedule = await db.fetchrow(
        "SELECT * FROM schedules WHERE id = $1 AND business_id = $2",
        uuid.UUID(schedule_id), uuid.UUID(current_user["business_id"])
    )
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found")

    schedule_data = json.loads(schedule["schedule_data"]) if isinstance(schedule["schedule_data"], str) else schedule["schedule_data"]

    # Load employee phone numbers
    employees = await db.fetch(
        "SELECT name, phone FROM employees WHERE business_id = $1",
        uuid.UUID(current_user["business_id"])
    )
    emp_phones = {e["name"]: e["phone"] for e in employees}

    sent_count = 0
    for row in schedule_data:
        phone = emp_phones.get(row["employee"])
        if not phone:
            continue

        success = await send_whatsapp(phone, row.get("whatsapp_msg", ""))
        if success:
            sent_count += 1
            # Log notification
            emp = await db.fetchrow(
                "SELECT id FROM employees WHERE name = $1 AND business_id = $2",
                row["employee"], uuid.UUID(current_user["business_id"])
            )
            await db.execute(
                """INSERT INTO notifications
                   (business_id, employee_id, schedule_id, type, recipient_name,
                    recipient_phone, message, delivered)
                   VALUES ($1, $2, $3, 'schedule', $4, $5, $6, TRUE)""",
                uuid.UUID(current_user["business_id"]),
                emp["id"] if emp else None,
                uuid.UUID(schedule_id),
                row["employee"], phone,
                row.get("whatsapp_msg", "")
            )

    # Mark schedule as WA sent
    await db.execute(
        "UPDATE schedules SET wa_sent = TRUE, wa_sent_at = NOW() WHERE id = $1",
        uuid.UUID(schedule_id)
    )

    return {"sent": sent_count, "total": len(schedule_data)}


# ── LIST SCHEDULES ────────────────────────────────────────────────────────────
@router.get("/list")
async def list_schedules(
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    rows = await db.fetch(
        """SELECT id, week_start, business_type, published, wa_sent,
                  generation_ms, created_at,
                  jsonb_array_length(schedule_data::jsonb) as employee_count
           FROM schedules
           WHERE business_id = $1
           ORDER BY created_at DESC
           LIMIT 20""",
        uuid.UUID(current_user["business_id"])
    )
    return [dict(r) for r in rows]
