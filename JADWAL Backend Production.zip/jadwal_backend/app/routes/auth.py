"""
JADWAL — Auth Routes
POST /api/auth/signup
POST /api/auth/login
POST /api/auth/logout
GET  /api/auth/me
POST /api/auth/refresh
"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
from typing import Optional
import jwt
import bcrypt
import uuid
import logging

from app.config import settings
from app.database import get_db, supabase
from app.services.email_service import send_welcome_email
from app.services.audit_service import log_action

router = APIRouter()
security = HTTPBearer()
logger = logging.getLogger(__name__)


# ── SCHEMAS ───────────────────────────────────────────────────────────────────
class SignupRequest(BaseModel):
    name: str
    email: EmailStr
    password: str
    business_name: str
    business_type: str = "Retail Store"
    phone: Optional[str] = None

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict
    business: dict


# ── JWT HELPERS ───────────────────────────────────────────────────────────────
def create_token(user_id: str, business_id: str) -> str:
    payload = {
        "sub": user_id,
        "business_id": business_id,
        "exp": datetime.utcnow() + timedelta(minutes=settings.JWT_EXPIRE_MINUTES),
        "iat": datetime.utcnow(),
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


# ── AUTH DEPENDENCY (use this to protect any route) ───────────────────────────
async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db=Depends(get_db)
) -> dict:
    """
    Add to any route: current_user = Depends(get_current_user)
    Returns: {user_id, business_id, email, name}
    """
    payload = decode_token(credentials.credentials)
    user = await db.fetchrow(
        """SELECT u.id, u.email, b.id as business_id, b.name as business_name,
                  b.plan, b.trial_ends_at
           FROM auth.users u
           JOIN businesses b ON b.owner_id = u.id
           WHERE u.id = $1""",
        uuid.UUID(payload["sub"])
    )
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return dict(user)


# ── SIGNUP ────────────────────────────────────────────────────────────────────
@router.post("/signup", response_model=TokenResponse)
async def signup(body: SignupRequest, db=Depends(get_db)):
    # Check email not taken
    existing = await db.fetchrow(
        "SELECT id FROM auth.users WHERE email = $1", body.email
    )
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    # Hash password
    hashed = bcrypt.hashpw(body.password.encode(), bcrypt.gensalt()).decode()

    # Create Supabase auth user
    try:
        auth_response = supabase.auth.admin.create_user({
            "email": body.email,
            "password": body.password,
            "email_confirm": True,
            "user_metadata": {"name": body.name}
        })
        user_id = auth_response.user.id
    except Exception as e:
        logger.error(f"Supabase auth error: {e}")
        raise HTTPException(status_code=500, detail="Could not create account")

    # Create business record
    business_id = str(uuid.uuid4())
    await db.execute(
        """INSERT INTO businesses (id, owner_id, name, business_type, phone, email, plan, trial_ends_at)
           VALUES ($1, $2, $3, $4, $5, $6, 'trial', NOW() + INTERVAL '30 days')""",
        uuid.UUID(business_id), uuid.UUID(user_id),
        body.business_name, body.business_type, body.phone, body.email
    )

    # Send welcome email
    await send_welcome_email(body.email, body.name, body.business_name)

    # Log signup
    await log_action(db, uuid.UUID(business_id), uuid.UUID(user_id),
                     "auth.signup", "business", uuid.UUID(business_id),
                     {"business_name": body.business_name})

    token = create_token(user_id, business_id)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {"id": user_id, "email": body.email, "name": body.name},
        "business": {"id": business_id, "name": body.business_name,
                     "plan": "trial", "type": body.business_type}
    }


# ── LOGIN ─────────────────────────────────────────────────────────────────────
@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, db=Depends(get_db)):
    try:
        auth_response = supabase.auth.sign_in_with_password({
            "email": body.email,
            "password": body.password
        })
        user_id = auth_response.user.id
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    business = await db.fetchrow(
        "SELECT id, name, plan, business_type, trial_ends_at FROM businesses WHERE owner_id = $1",
        uuid.UUID(user_id)
    )
    if not business:
        raise HTTPException(status_code=404, detail="Business not found")

    token = create_token(user_id, str(business["id"]))
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {"id": user_id, "email": body.email,
                 "name": auth_response.user.user_metadata.get("name", "")},
        "business": dict(business)
    }


# ── ME ────────────────────────────────────────────────────────────────────────
@router.get("/me")
async def me(current_user: dict = Depends(get_current_user)):
    return current_user


# ── LOGOUT ────────────────────────────────────────────────────────────────────
@router.post("/logout")
async def logout(current_user: dict = Depends(get_current_user)):
    # JWT is stateless — client just deletes the token
    # For extra security, add token to a Redis blocklist here
    return {"message": "Logged out successfully"}
