"""
JADWAL — Webhooks + Background Scheduler
Automated daily jobs:
- Visa expiry alerts (90 / 30 / 7 days)
- Work permit renewal reminders (60 / 30 days)
- Probation end warnings (30 days)
- EOS alerts on deactivation
"""
from fastapi import APIRouter, Request
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import date, timedelta
import logging, asyncpg

from app.config import settings
from app.services.email_service import send_visa_alert, send_whatsapp
from app.database import get_pool

router = APIRouter()
logger = logging.getLogger(__name__)

# APScheduler — runs inside the FastAPI process
scheduler = AsyncIOScheduler()


# ── DAILY VISA & PERMIT CHECKS ────────────────────────────────────────────────
async def run_daily_alerts():
    """Runs at 8:00 AM UAE time every day. Sends alerts for expiring visas, permits, probation."""
    logger.info("Running daily HR alerts job...")
    pool = await get_pool()
    today = date.today()

    async with pool.acquire() as db:
        # Get all businesses with their owner email
        businesses = await db.fetch(
            """SELECT b.id, b.name, u.email
               FROM businesses b
               JOIN auth.users u ON u.id = b.owner_id
               WHERE b.plan != 'trial' OR b.trial_ends_at > NOW()"""
        )

        for biz in businesses:
            biz_id = biz["id"]

            # Load active employees
            emps = await db.fetch(
                """SELECT name, phone, visa_expiry, permit_expiry, join_date, nationality
                   FROM employees WHERE business_id=$1 AND active=TRUE""",
                biz_id
            )

            for emp in emps:
                # ── VISA EXPIRY ──────────────────────────────────────────────
                if emp["visa_expiry"]:
                    days = (emp["visa_expiry"] - today).days
                    if days in settings.VISA_ALERT_DAYS or days < 0:
                        logger.info(f"Visa alert: {emp['name']} — {days} days")
                        await send_visa_alert(
                            biz["email"],
                            emp["name"],
                            days,
                            str(emp["visa_expiry"])
                        )
                        # Also WhatsApp the business owner
                        wa_msg = (
                            f"🛂 JADWAL Visa Alert\n\n"
                            f"Employee: {emp['name']}\n"
                            f"Visa expiry: {emp['visa_expiry']}\n"
                            f"{'⚠ EXPIRED' if days < 0 else f'Expires in {days} days'}\n\n"
                            f"Action required: Go to HR Automation → Work Permits\n"
                            f"MOHRE eServices: eservices.mohre.gov.ae"
                        )
                        # Get owner phone
                        biz_row = await db.fetchrow(
                            "SELECT phone FROM businesses WHERE id=$1", biz_id
                        )
                        if biz_row and biz_row["phone"]:
                            await send_whatsapp(biz_row["phone"], wa_msg)

                # ── PERMIT EXPIRY ─────────────────────────────────────────────
                if emp["permit_expiry"]:
                    days = (emp["permit_expiry"] - today).days
                    if days in [60, 30, 14, 0] or days < 0:
                        logger.info(f"Permit alert: {emp['name']} — {days} days")
                        # Log to notifications table
                        await db.execute(
                            """INSERT INTO notifications
                               (business_id, type, recipient_name, message, channel, delivered)
                               VALUES ($1,'permit_alert',$2,$3,'system',TRUE)""",
                            biz_id,
                            emp["name"],
                            f"Work permit for {emp['name']} {'EXPIRED' if days<0 else f'expires in {days} days'}"
                        )

                # ── PROBATION END ─────────────────────────────────────────────
                if emp["join_date"]:
                    elapsed = (today - emp["join_date"]).days
                    days_left = 180 - elapsed
                    if days_left in [30, 14, 7] and elapsed <= 180:
                        logger.info(f"Probation alert: {emp['name']} — {days_left} days left")
                        await db.execute(
                            """INSERT INTO notifications
                               (business_id, type, recipient_name, message, channel, delivered)
                               VALUES ($1,'probation_alert',$2,$3,'system',TRUE)""",
                            biz_id,
                            emp["name"],
                            f"Probation ends in {days_left} days for {emp['name']} — decide: confirm or issue 14-day notice"
                        )

        logger.info("Daily HR alerts job complete.")


# ── TRIAL EXPIRY CHECK ────────────────────────────────────────────────────────
async def check_trial_expiry():
    """Check for trials ending in 3 days — send upgrade reminder."""
    pool = await get_pool()
    reminder_date = date.today() + timedelta(days=3)
    async with pool.acquire() as db:
        trials = await db.fetch(
            """SELECT b.name, b.id, u.email
               FROM businesses b JOIN auth.users u ON u.id=b.owner_id
               WHERE b.plan='trial' AND DATE(b.trial_ends_at)=$1""",
            reminder_date
        )
        for t in trials:
            logger.info(f"Trial ending reminder: {t['name']}")
            # TODO: send upgrade reminder email


# ── START SCHEDULER WITH APP ──────────────────────────────────────────────────
def start_scheduler():
    """Call this on app startup."""
    # Daily alerts at 8:00 AM UAE time (UTC+4 = 04:00 UTC)
    scheduler.add_job(
        run_daily_alerts,
        CronTrigger(hour=4, minute=0, timezone="UTC"),
        id="daily_hr_alerts",
        replace_existing=True,
        misfire_grace_time=3600
    )
    # Trial expiry check at 9:00 AM UAE
    scheduler.add_job(
        check_trial_expiry,
        CronTrigger(hour=5, minute=0, timezone="UTC"),
        id="trial_expiry_check",
        replace_existing=True
    )
    scheduler.start()
    logger.info("Background scheduler started — daily alerts at 08:00 UAE time")

def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
