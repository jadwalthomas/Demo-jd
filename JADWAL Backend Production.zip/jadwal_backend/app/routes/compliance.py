"""
JADWAL — Compliance Routes
GET /api/compliance/emiratisation   Live Emiratisation data
GET /api/compliance/wps             WPS file data for current month
GET /api/compliance/summary         Full compliance dashboard
GET /api/compliance/audit-log       Action history
"""
from fastapi import APIRouter, Depends, Response
from datetime import date, datetime
import uuid, json, logging

from app.routes.auth import get_current_user
from app.database import get_db
from app.config import settings

router = APIRouter()
logger = logging.getLogger(__name__)


# ── EMIRATISATION ─────────────────────────────────────────────────────────────
@router.get("/emiratisation")
async def emiratisation(current_user=Depends(get_current_user), db=Depends(get_db)):
    biz_id = uuid.UUID(current_user["business_id"])
    emps = await db.fetch(
        "SELECT id,name,nationality,role FROM employees WHERE business_id=$1 AND active=TRUE",
        biz_id
    )
    total = len(emps)
    emiratis = sum(1 for e in emps if e["nationality"] == "Emirati")
    pct = round(emiratis / total * 100) if total else 0

    # Fine calculation (AED 7,000 per missing Emirati)
    targets = {
        2026: max(0, round(total * 0.02) - emiratis),
        2027: max(0, round(total * 0.04) - emiratis),
        2028: max(0, round(total * 0.05) - emiratis),
        2030: max(0, round(total * 0.10) - emiratis),
    }
    fine_monthly = targets[2026] * settings.EMIRATISATION_FINE_PER_MONTH

    # Company class
    if pct >= 5:   company_class = "A"
    elif pct >= 2: company_class = "B"
    else:          company_class = "C"

    return {
        "total_employees": total,
        "emirati_count": emiratis,
        "emirati_percentage": pct,
        "company_class": company_class,
        "fine_monthly_aed": fine_monthly,
        "fine_annual_aed": fine_monthly * 12,
        "gap_to_2026": targets[2026],
        "gap_to_2030": targets[2030],
        "employees": [{"id":str(e["id"]),"name":e["name"],
                       "nationality":e["nationality"],"role":e["role"]} for e in emps],
        "milestones": [
            {"year":2026,"target_pct":2,"target_count":max(0,round(total*.02)),"current":emiratis,"met":emiratis>=round(total*.02)},
            {"year":2027,"target_pct":4,"target_count":max(0,round(total*.04)),"current":emiratis,"met":emiratis>=round(total*.04)},
            {"year":2028,"target_pct":5,"target_count":max(0,round(total*.05)),"current":emiratis,"met":emiratis>=round(total*.05)},
            {"year":2030,"target_pct":10,"target_count":max(0,round(total*.10)),"current":emiratis,"met":emiratis>=round(total*.10)},
        ]
    }


# ── WPS SIF FILE ──────────────────────────────────────────────────────────────
@router.get("/wps")
async def wps_data(
    month: str = None,   # YYYY-MM format, defaults to current month
    download: bool = False,
    current_user=Depends(get_current_user),
    db=Depends(get_db)
):
    biz_id = uuid.UUID(current_user["business_id"])
    if not month:
        month = date.today().strftime("%Y-%m")

    yr, mn = month.split("-")

    emps = await db.fetch(
        "SELECT name,emirates_id,salary FROM employees WHERE business_id=$1 AND active=TRUE AND salary>0",
        biz_id
    )

    total_salary = sum(float(e["salary"]) for e in emps)

    # Generate SIF file content (UAE Central Bank WPS 2.0 format)
    lines = [f"H|{yr}{mn}01|JADWAL001|AED|{len(emps)}|{total_salary:.2f}"]
    for emp in emps:
        sal = float(emp["salary"])
        lines.append(
            f"D|{emp['emirates_id'] or 'N/A'}|{emp['name']}|"
            f"{sal:.2f}|{sal:.2f}|00.00|00.00|{yr}{mn}25|1"
        )
    lines.append(f"T|{len(emps)}|{total_salary:.2f}")
    sif_content = "\n".join(lines)

    if download:
        return Response(
            content=sif_content,
            media_type="text/plain",
            headers={"Content-Disposition": f"attachment; filename=JADWAL_WPS_{month.replace('-','')}.sif"}
        )

    return {
        "month": month,
        "employee_count": len(emps),
        "total_salary_aed": total_salary,
        "employees_without_salary": await db.fetchval(
            "SELECT COUNT(*) FROM employees WHERE business_id=$1 AND active=TRUE AND (salary=0 OR salary IS NULL)",
            biz_id
        ),
        "sif_preview": sif_content,
        "mandatory_from": "July 2026",
        "format": "UAE Central Bank WPS 2.0"
    }


# ── FULL COMPLIANCE SUMMARY ───────────────────────────────────────────────────
@router.get("/summary")
async def compliance_summary(current_user=Depends(get_current_user), db=Depends(get_db)):
    biz_id = uuid.UUID(current_user["business_id"])
    today = date.today()

    emps = await db.fetch(
        "SELECT * FROM employees WHERE business_id=$1 AND active=TRUE", biz_id
    )
    total = len(emps)

    # Visa alerts
    visa_expired  = sum(1 for e in emps if e["visa_expiry"] and (e["visa_expiry"]-today).days < 0)
    visa_critical = sum(1 for e in emps if e["visa_expiry"] and 0 <= (e["visa_expiry"]-today).days <= 30)
    visa_warning  = sum(1 for e in emps if e["visa_expiry"] and 31 <= (e["visa_expiry"]-today).days <= 90)

    # Permit alerts
    permit_expired  = sum(1 for e in emps if e["permit_expiry"] and (e["permit_expiry"]-today).days < 0)
    permit_warning  = sum(1 for e in emps if e["permit_expiry"] and 0 <= (e["permit_expiry"]-today).days <= 60)

    # Documents
    docs_complete = 0
    for e in emps:
        docs = e["documents"] or {}
        if isinstance(docs, str): docs = json.loads(docs)
        if docs.get("passport") and docs.get("visa_copy") and docs.get("employment_contract"):
            docs_complete += 1

    # Emiratisation
    emiratis = sum(1 for e in emps if e["nationality"] == "Emirati")
    pct = round(emiratis / total * 100) if total else 0
    fine = max(0, round(total * 0.02) - emiratis) * settings.EMIRATISATION_FINE_PER_MONTH

    # Probation
    on_probation = sum(1 for e in emps if e["join_date"] and 0 < (today-e["join_date"]).days <= 180)

    return {
        "overall_status": "compliant" if fine==0 and visa_expired==0 and permit_expired==0 else "action_required",
        "emiratisation": {
            "percentage": pct,
            "emiratis": emiratis,
            "total": total,
            "fine_monthly_aed": fine,
            "status": "compliant" if pct >= 2 else "at_risk"
        },
        "visas": {
            "expired": visa_expired,
            "expiring_30_days": visa_critical,
            "expiring_90_days": visa_warning,
            "status": "action_required" if visa_expired > 0 else "monitor" if visa_critical > 0 else "ok"
        },
        "work_permits": {
            "expired": permit_expired,
            "expiring_60_days": permit_warning,
            "status": "action_required" if permit_expired > 0 else "ok"
        },
        "documents": {
            "complete": docs_complete,
            "incomplete": total - docs_complete,
            "completion_pct": round(docs_complete / total * 100) if total else 0
        },
        "probation": {
            "on_probation": on_probation,
            "completed": total - on_probation
        },
        "midday_break_law": {
            "active": today.month in [6,7,8,9],
            "months": "June – September",
            "law": "UAE Article 66"
        },
        "wps_status": {
            "mandatory_from": "July 2026",
            "status": "compliant"
        }
    }


# ── AUDIT LOG ─────────────────────────────────────────────────────────────────
@router.get("/audit-log")
async def audit_log(
    limit: int = 50,
    current_user=Depends(get_current_user),
    db=Depends(get_db)
):
    rows = await db.fetch(
        """SELECT action, entity_type, entity_id, details, created_at
           FROM audit_log
           WHERE business_id=$1
           ORDER BY created_at DESC
           LIMIT $2""",
        uuid.UUID(current_user["business_id"]), limit
    )
    return [dict(r) for r in rows]
