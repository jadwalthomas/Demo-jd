"""
JADWAL — File Upload Routes
Secure document storage via Supabase Storage
POST /api/files/upload/{employee_id}/{doc_type}
GET  /api/files/{employee_id}/{doc_type}
DELETE /api/files/{document_id}
"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from typing import Literal
import uuid
import logging

from app.config import settings
from app.database import get_db, supabase
from app.routes.auth import get_current_user
from app.services.audit_service import log_action

router = APIRouter()
logger = logging.getLogger(__name__)

DocType = Literal["passport", "emirates_id", "visa_copy", "employment_contract", "medical_certificate"]

ALLOWED_MIME_TYPES = {
    "image/jpeg", "image/png", "image/webp",
    "application/pdf"
}

MAX_SIZE_BYTES = settings.MAX_FILE_SIZE_MB * 1024 * 1024


# ── UPLOAD DOCUMENT ───────────────────────────────────────────────────────────
@router.post("/upload/{employee_id}/{doc_type}")
async def upload_document(
    employee_id: str,
    doc_type: DocType,
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    # Verify employee belongs to this business
    emp = await db.fetchrow(
        "SELECT id, name FROM employees WHERE id = $1 AND business_id = $2",
        uuid.UUID(employee_id), uuid.UUID(current_user["business_id"])
    )
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    # Validate file type
    if file.content_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"File type not allowed. Upload PDF, JPG, PNG, or WebP."
        )

    # Read and validate size
    content = await file.read()
    if len(content) > MAX_SIZE_BYTES:
        raise HTTPException(
            status_code=400,
            detail=f"File too large. Maximum size is {settings.MAX_FILE_SIZE_MB}MB."
        )

    # Storage path: {business_id}/{employee_id}/{doc_type}/{filename}
    ext = file.filename.split(".")[-1] if "." in file.filename else "pdf"
    storage_path = f"{current_user['business_id']}/{employee_id}/{doc_type}/{uuid.uuid4()}.{ext}"

    # Upload to Supabase Storage
    try:
        supabase.storage.from_(settings.STORAGE_BUCKET).upload(
            path=storage_path,
            file=content,
            file_options={"content-type": file.content_type}
        )
    except Exception as e:
        logger.error(f"Storage upload error: {e}")
        raise HTTPException(status_code=500, detail="File upload failed")

    # Save document record
    doc_id = uuid.uuid4()
    await db.execute(
        """INSERT INTO employee_documents
           (id, employee_id, business_id, doc_type, file_name, storage_path, file_size_kb, mime_type, uploaded_by)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)""",
        doc_id,
        uuid.UUID(employee_id),
        uuid.UUID(current_user["business_id"]),
        doc_type,
        file.filename,
        storage_path,
        len(content) // 1024,
        file.content_type,
        uuid.UUID(current_user["id"])
    )

    # Update employee documents checklist
    doc_key_map = {
        "passport": "passport",
        "emirates_id": "emirates_id",
        "visa_copy": "visa_copy",
        "employment_contract": "employment_contract",
        "medical_certificate": "medical_certificate",
    }
    await db.execute(
        f"""UPDATE employees
            SET documents = documents || '{{"{ doc_key_map[doc_type]}": true}}'::jsonb
            WHERE id = $1""",
        uuid.UUID(employee_id)
    )

    # Check if all docs complete — update hr_status
    updated_emp = await db.fetchrow(
        "SELECT documents FROM employees WHERE id = $1",
        uuid.UUID(employee_id)
    )
    docs = updated_emp["documents"] or {}
    all_complete = all([
        docs.get("passport"), docs.get("visa_copy"),
        docs.get("employment_contract")
    ])
    if all_complete:
        await db.execute(
            "UPDATE employees SET hr_status = 'ready' WHERE id = $1 AND hr_status = 'pending'",
            uuid.UUID(employee_id)
        )

    await log_action(db, uuid.UUID(current_user["business_id"]),
                     uuid.UUID(current_user["id"]),
                     "document.uploaded", "employee", uuid.UUID(employee_id),
                     {"doc_type": doc_type, "file_name": file.filename})

    return {
        "document_id": str(doc_id),
        "doc_type": doc_type,
        "employee": emp["name"],
        "file_name": file.filename,
        "size_kb": len(content) // 1024,
        "hr_status_updated": all_complete,
        "message": f"{doc_type} uploaded successfully"
    }


# ── GET SIGNED URL ────────────────────────────────────────────────────────────
@router.get("/{employee_id}/{doc_type}/url")
async def get_document_url(
    employee_id: str,
    doc_type: DocType,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    """Get a time-limited signed URL to view a document (expires in 1 hour)."""
    doc = await db.fetchrow(
        """SELECT storage_path FROM employee_documents
           WHERE employee_id = $1 AND doc_type = $2 AND business_id = $3
           ORDER BY created_at DESC LIMIT 1""",
        uuid.UUID(employee_id), doc_type, uuid.UUID(current_user["business_id"])
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    try:
        signed = supabase.storage.from_(settings.STORAGE_BUCKET).create_signed_url(
            doc["storage_path"], expires_in=3600   # 1 hour
        )
        return {"url": signed["signedURL"], "expires_in": 3600}
    except Exception as e:
        logger.error(f"Signed URL error: {e}")
        raise HTTPException(status_code=500, detail="Could not generate document URL")


# ── DELETE DOCUMENT ───────────────────────────────────────────────────────────
@router.delete("/{document_id}")
async def delete_document(
    document_id: str,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    doc = await db.fetchrow(
        "SELECT * FROM employee_documents WHERE id = $1 AND business_id = $2",
        uuid.UUID(document_id), uuid.UUID(current_user["business_id"])
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    # Delete from storage
    try:
        supabase.storage.from_(settings.STORAGE_BUCKET).remove([doc["storage_path"]])
    except Exception as e:
        logger.warning(f"Storage delete warning: {e}")

    # Delete record
    await db.execute("DELETE FROM employee_documents WHERE id = $1", uuid.UUID(document_id))

    # Update employee checklist
    await db.execute(
        f"""UPDATE employees
            SET documents = documents || '{{"{ doc["doc_type"]}": false}}'::jsonb
            WHERE id = $1""",
        doc["employee_id"]
    )

    return {"message": "Document deleted"}
