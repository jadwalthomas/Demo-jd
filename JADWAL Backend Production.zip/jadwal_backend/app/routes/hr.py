"""
JADWAL — HR Routes
GET  /api/hr/employees/{id}           Full HR profile
GET  /api/hr/alerts                   All HR alerts for business
POST /api/hr/leave                    Record leave
GET  /api/hr/leave/{employee_id}      Leave history
GET  /api/hr/eos/{employee_id}        EOS calculation
PATCH /api/hr/onboarding/{emp_id}     Update onboarding checklist
GET  /api/hr/dashboard                HR dashboard summary
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import date
import uuid, json, logging

from app.routes.auth import get_current_user
from app.database import get_db
from app.services.audit_service import log_action

router = APIRouter()
logger = logging.getLogger(__name__)

class LeaveRecord(BaseModel):
    employee_id: str
    leave_type: str          # annual | sick | unpaid | hajj | maternity
    start_date: str
    end_date: str
    days: int
    reason: Optional[str] = None

class OnboardingUpdate(BaseModel):
    checklist: dict          # {contract_signed: true, mohre_applied: false, ...}


# ── HR DASHBOARD ──────────────────────────────────────────────────────────────
@router.get("/dashboard")
async def hr_dashboard(current_user=Depends(get_current_user), db=Depends(get_db)):
    biz_id = uuid.UUID(current_user["business_id"])
    emps = await db.fetch(
        "SELECT * FROM employees WHERE business_id=$1 AND active=TRUE", biz_id
    )
    today = date.today()
    alerts = []

    for e in emps:
        # Visa expiry
        if e["visa_expiry"]:
            days = (e["visa_expiry"] - today).days
            if days <= 90:
                alerts.append({"type":"visa","severity":"critical" if days<=30 else "warning",
                               "employee":e["name"],"message":f"Visa expires in {days} days" if days>=0 else f"Visa EXPIRED {abs(days)} days ago","days":days})
        # Permit expiry
        if e["permit_expiry"]:
            days = (e["permit_expiry"] - today).days
            if days <= 60:
                alerts.append({"type":"permit","severity":"critical" if days<=14 else "warning",
                               "employee":e["name"],"message":f"Work permit expires in {days} days" if days>=0 else f"Permit EXPIRED","days":days})
        # Missing docs
        docs = e["documents"] or {}
        if isinstance(docs, str): docs = json.loads(docs)
        missing = [k for k,v in docs.items() if not v]
        if missing:
            alerts.append({"type":"documents","severity":"info","employee":e["name"],
                           "message":f"Missing: {', '.join(missing)}","missing":missing})
        # Probation
        if e["join_date"]:
            elapsed = (today - e["join_date"]).days
            if 0 < elapsed <= 180:
                left = 180 - elapsed
                if left <= 30:
                    alerts.append({"type":"probation","severity":"warning","employee":e["name"],
                                   "message":f"Probation ends in {left} days","days":left})
        # Leave exhausted
        if (e["annual_leave_used"] or 0) >= (e["annual_leave_days"] or 30):
            alerts.append({"type":"leave","severity":"info","employee":e["name"],
                           "message":"Annual leave fully used"})

    return {
        "total_employees": len(emps),
        "pending_hr": sum(1 for e in emps if e["hr_status"]=="pending"),
        "ready_hr":   sum(1 for e in emps if e["hr_status"]=="ready"),
        "alerts":     sorted(alerts, key=lambda x: {"critical":0,"warning":1,"info":2}[x["severity"]]),
        "alert_count": len(alerts),
    }


# ── FULL HR PROFILE ───────────────────────────────────────────────────────────
@router.get("/employees/{eid}")
async def hr_profile(eid: str, current_user=Depends(get_current_user), db=Depends(get_db)):
    emp = await db.fetchrow(
        "SELECT * FROM employees WHERE id=$1 AND business_id=$2",
        uuid.UUID(eid), uuid.UUID(current_user["business_id"])
    )
    if not emp: raise HTTPException(404, "Employee not found")

    docs = await db.fetch(
        "SELECT id,doc_type,file_name,created_at,expires_at FROM employee_documents WHERE employee_id=$1 ORDER BY created_at DESC",
        uuid.UUID(eid)
    )
    leaves = await db.fetch(
        "SELECT * FROM leave_requests WHERE employee_id=$1 ORDER BY start_date DESC LIMIT 20",
        uuid.UUID(eid)
    )

    # EOS calculation
    today = date.today()
    eos = 0
    years = 0
    if emp["join_date"]:
        years = (today - emp["join_date"]).days / 365.25
        basic = float(emp["basic_salary"] or emp["salary"] * 0.6)
        if years >= 1:
            if years <= 5:
                eos = round(basic / 30 * 21 * years)
            else:
                eos = round(basic / 30 * 21 * 5 + basic / 30 * 30 * (years - 5))

    return {
        **dict(emp),
        "documents_on_file": [dict(d) for d in docs],
        "leave_history": [dict(l) for l in leaves],
        "eos_calculation": {
            "years_of_service": round(years, 2),
            "basic_salary": float(emp["basic_salary"] or 0),
            "gratuity_aed": eos,
            "eligible": years >= 1,
        }
    }


# ── RECORD LEAVE ──────────────────────────────────────────────────────────────
@router.post("/leave")
async def record_leave(body: LeaveRecord, current_user=Depends(get_current_user), db=Depends(get_db)):
    emp = await db.fetchrow(
        "SELECT id,name,annual_leave_used,sick_leave_used FROM employees WHERE id=$1 AND business_id=$2",
        uuid.UUID(body.employee_id), uuid.UUID(current_user["business_id"])
    )
    if not emp: raise HTTPException(404,"Employee not found")

    leave_id = uuid.uuid4()
    await db.execute(
        """INSERT INTO leave_requests
           (id,business_id,employee_id,leave_type,start_date,end_date,days,reason,status,recorded_by)
           VALUES($1,$2,$3,$4,$5,$6,$7,$8,'approved',$9)""",
        leave_id, uuid.UUID(current_user["business_id"]),
        uuid.UUID(body.employee_id), body.leave_type,
        body.start_date, body.end_date, body.days, body.reason,
        uuid.UUID(current_user["id"])
    )

    # Deduct from balance
    if body.leave_type == "annual":
        await db.execute(
            "UPDATE employees SET annual_leave_used=annual_leave_used+$1 WHERE id=$2",
            body.days, uuid.UUID(body.employee_id)
        )
    elif body.leave_type == "sick":
        await db.execute(
            "UPDATE employees SET sick_leave_used=sick_leave_used+$1 WHERE id=$2",
            body.days, uuid.UUID(body.employee_id)
        )

    await log_action(db,uuid.UUID(current_user["business_id"]),uuid.UUID(current_user["id"]),
                     "leave.recorded","employee",uuid.UUID(body.employee_id),
                     {"type":body.leave_type,"days":body.days})
    return {"leave_id": str(leave_id), "message": f"{body.days} days {body.leave_type} leave recorded"}


# ── LEAVE HISTORY ─────────────────────────────────────────────────────────────
@router.get("/leave/{eid}")
async def leave_history(eid: str, current_user=Depends(get_current_user), db=Depends(get_db)):
    rows = await db.fetch(
        """SELECT lr.*, e.name as employee_name
           FROM leave_requests lr
           JOIN employees e ON e.id=lr.employee_id
           WHERE lr.employee_id=$1 AND lr.business_id=$2
           ORDER BY lr.start_date DESC""",
        uuid.UUID(eid), uuid.UUID(current_user["business_id"])
    )
    return [dict(r) for r in rows]


# ── EOS CALCULATOR ────────────────────────────────────────────────────────────
@router.get("/eos/{eid}")
async def eos_calculator(eid: str, current_user=Depends(get_current_user), db=Depends(get_db)):
    emp = await db.fetchrow(
        "SELECT name,join_date,salary,basic_salary FROM employees WHERE id=$1 AND business_id=$2",
        uuid.UUID(eid), uuid.UUID(current_user["business_id"])
    )
    if not emp: raise HTTPException(404,"Employee not found")
    if not emp["join_date"]:
        return {"eligible":False,"reason":"No join date recorded"}

    today = date.today()
    years = (today - emp["join_date"]).days / 365.25
    basic = float(emp["basic_salary"] or emp["salary"] * 0.6)

    if years < 1:
        return {"eligible":False,"years_of_service":round(years,2),
                "reason":"Less than 1 year — not yet eligible for gratuity"}

    if years <= 5:
        gratuity = round(basic / 30 * 21 * years)
    else:
        gratuity = round(basic / 30 * 21 * 5 + basic / 30 * 30 * (years - 5))

    return {
        "employee": emp["name"],
        "join_date": str(emp["join_date"]),
        "years_of_service": round(years, 2),
        "total_salary_aed": float(emp["salary"]),
        "basic_salary_aed": round(basic, 2),
        "gratuity_aed": gratuity,
        "eligible": True,
        "formula": "21 days basic per year (yrs 1-5) + 30 days per year (yrs 5+)",
        "law": "UAE Federal Decree Law No. 33 of 2021"
    }


# ── ONBOARDING CHECKLIST ──────────────────────────────────────────────────────
@router.patch("/onboarding/{eid}")
async def update_onboarding(eid: str, body: OnboardingUpdate,
                            current_user=Depends(get_current_user), db=Depends(get_db)):
    emp = await db.fetchrow(
        "SELECT id FROM employees WHERE id=$1 AND business_id=$2",
        uuid.UUID(eid), uuid.UUID(current_user["business_id"])
    )
    if not emp: raise HTTPException(404,"Employee not found")

    import json as _json
    await db.execute(
        "UPDATE employees SET onboarding=onboarding||$1::jsonb WHERE id=$2",
        _json.dumps(body.checklist), uuid.UUID(eid)
    )

    # If all core steps done, mark onboarding_done
    updated = await db.fetchrow("SELECT onboarding FROM employees WHERE id=$1",uuid.UUID(eid))
    ob = updated["onboarding"] or {}
    if isinstance(ob,str): ob=_json.loads(ob)
    core = ["contract_signed","mohre_applied","wps_activated"]
    if all(ob.get(k) for k in core):
        await db.execute("UPDATE employees SET onboarding_done=TRUE WHERE id=$1",uuid.UUID(eid))

    return {"message":"Onboarding checklist updated","onboarding":ob}


# ── ALL HR ALERTS ─────────────────────────────────────────────────────────────
@router.get("/alerts")
async def hr_alerts(current_user=Depends(get_current_user), db=Depends(get_db)):
    dashboard = await hr_dashboard(current_user=current_user, db=db)
    return dashboard["alerts"]
