"""
JADWAL — Employees Routes
GET    /api/employees           List all
POST   /api/employees           Create
GET    /api/employees/{id}      Get one
PUT    /api/employees/{id}      Update
DELETE /api/employees/{id}      Delete
PATCH  /api/employees/{id}/toggle  Toggle active
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional
import uuid, logging
from app.routes.auth import get_current_user
from app.database import get_db
from app.services.audit_service import log_action

router = APIRouter()
logger = logging.getLogger(__name__)

class EmployeeIn(BaseModel):
    name: str
    name_ar: Optional[str] = None
    role: str
    phone: str
    email: Optional[str] = None
    nationality: str = "Emirati"
    emirates_id: Optional[str] = None
    salary: float = 0
    max_hours_week: int = 40
    join_date: Optional[str] = None
    visa_expiry: Optional[str] = None
    permit_number: Optional[str] = None
    permit_expiry: Optional[str] = None

@router.get("/")
async def list_employees(active_only: bool=False, current_user=Depends(get_current_user), db=Depends(get_db)):
    q = "SELECT * FROM employees WHERE business_id=$1"
    if active_only: q += " AND active=TRUE"
    q += " ORDER BY name"
    rows = await db.fetch(q, uuid.UUID(current_user["business_id"]))
    return [dict(r) for r in rows]

@router.post("/", status_code=201)
async def create_employee(body: EmployeeIn, current_user=Depends(get_current_user), db=Depends(get_db)):
    nat = "Emirati" if (body.emirates_id or "").startswith("784") else body.nationality
    eid = uuid.uuid4()
    await db.execute(
        """INSERT INTO employees
           (id,business_id,name,name_ar,role,phone,email,nationality,emirates_id,
            salary,max_hours_week,join_date,visa_expiry,permit_number,permit_expiry,hr_status)
           VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,'pending')""",
        eid, uuid.UUID(current_user["business_id"]),
        body.name,body.name_ar,body.role,body.phone,body.email,
        nat,body.emirates_id,body.salary,body.max_hours_week,
        body.join_date,body.visa_expiry,body.permit_number,body.permit_expiry
    )
    await log_action(db,uuid.UUID(current_user["business_id"]),uuid.UUID(current_user["id"]),
                     "employee.created","employee",eid,{"name":body.name,"role":body.role})
    row = await db.fetchrow("SELECT * FROM employees WHERE id=$1", eid)
    return dict(row)

@router.get("/{eid}")
async def get_employee(eid: str, current_user=Depends(get_current_user), db=Depends(get_db)):
    row = await db.fetchrow("SELECT * FROM employees WHERE id=$1 AND business_id=$2",
                            uuid.UUID(eid), uuid.UUID(current_user["business_id"]))
    if not row: raise HTTPException(404,"Employee not found")
    return dict(row)

@router.put("/{eid}")
async def update_employee(eid: str, body: EmployeeIn, current_user=Depends(get_current_user), db=Depends(get_db)):
    row = await db.fetchrow("SELECT id FROM employees WHERE id=$1 AND business_id=$2",
                            uuid.UUID(eid), uuid.UUID(current_user["business_id"]))
    if not row: raise HTTPException(404,"Employee not found")
    nat = "Emirati" if (body.emirates_id or "").startswith("784") else body.nationality
    await db.execute(
        """UPDATE employees SET name=$2,name_ar=$3,role=$4,phone=$5,email=$6,
           nationality=$7,emirates_id=$8,salary=$9,max_hours_week=$10,
           join_date=$11,visa_expiry=$12,permit_number=$13,permit_expiry=$14,
           updated_at=NOW() WHERE id=$1""",
        uuid.UUID(eid),body.name,body.name_ar,body.role,body.phone,body.email,
        nat,body.emirates_id,body.salary,body.max_hours_week,
        body.join_date,body.visa_expiry,body.permit_number,body.permit_expiry
    )
    await log_action(db,uuid.UUID(current_user["business_id"]),uuid.UUID(current_user["id"]),
                     "employee.updated","employee",uuid.UUID(eid),{"name":body.name})
    updated = await db.fetchrow("SELECT * FROM employees WHERE id=$1",uuid.UUID(eid))
    return dict(updated)

@router.patch("/{eid}/toggle")
async def toggle(eid: str, current_user=Depends(get_current_user), db=Depends(get_db)):
    row = await db.fetchrow("SELECT active,name FROM employees WHERE id=$1 AND business_id=$2",
                            uuid.UUID(eid), uuid.UUID(current_user["business_id"]))
    if not row: raise HTTPException(404,"Employee not found")
    new = not row["active"]
    await db.execute("UPDATE employees SET active=$1,updated_at=NOW() WHERE id=$2",new,uuid.UUID(eid))
    return {"id":eid,"active":new,"name":row["name"]}

@router.delete("/{eid}")
async def delete_employee(eid: str, current_user=Depends(get_current_user), db=Depends(get_db)):
    row = await db.fetchrow("SELECT name FROM employees WHERE id=$1 AND business_id=$2",
                            uuid.UUID(eid), uuid.UUID(current_user["business_id"]))
    if not row: raise HTTPException(404,"Employee not found")
    await db.execute("DELETE FROM employees WHERE id=$1",uuid.UUID(eid))
    await log_action(db,uuid.UUID(current_user["business_id"]),uuid.UUID(current_user["id"]),
                     "employee.deleted","employee",uuid.UUID(eid),{"name":row["name"]})
    return {"message":f"{row['name']} removed"}
