"""
JADWAL — Payment Routes
POST /api/payments/paypal/create-order
POST /api/payments/paypal/capture
POST /api/payments/ziina/create
GET  /api/payments/status
POST /api/webhooks/paypal        (webhook receiver)
POST /api/webhooks/ziina         (webhook receiver)
"""

from fastapi import APIRouter, Depends, HTTPException, Request, Header
from pydantic import BaseModel
from typing import Optional
import httpx
import hmac
import hashlib
import json
import uuid
import logging

from app.config import settings
from app.database import get_db
from app.routes.auth import get_current_user
from app.services.email_service import send_payment_confirmation
from app.services.audit_service import log_action

router = APIRouter()
logger = logging.getLogger(__name__)

PLAN_PRICES = {
    "starter": {"AED": 299, "USD": 81},
    "growth":  {"AED": 699, "USD": 190},
}


# ── PAYPAL HELPERS ────────────────────────────────────────────────────────────
async def get_paypal_token() -> str:
    base = "https://api-m.sandbox.paypal.com" if settings.PAYPAL_MODE == "sandbox" \
           else "https://api-m.paypal.com"
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{base}/v1/oauth2/token",
            auth=(settings.PAYPAL_CLIENT_ID, settings.PAYPAL_CLIENT_SECRET),
            data={"grant_type": "client_credentials"}
        )
        return resp.json()["access_token"]

async def paypal_request(method: str, path: str, body: dict = None) -> dict:
    base = "https://api-m.sandbox.paypal.com" if settings.PAYPAL_MODE == "sandbox" \
           else "https://api-m.paypal.com"
    token = await get_paypal_token()
    async with httpx.AsyncClient() as client:
        fn = getattr(client, method)
        resp = await fn(
            f"{base}{path}",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
            json=body
        )
        return resp.json()


# ── CREATE PAYPAL ORDER ───────────────────────────────────────────────────────
class CreateOrderRequest(BaseModel):
    plan: str   # starter | growth

@router.post("/paypal/create-order")
async def create_paypal_order(
    body: CreateOrderRequest,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    if body.plan not in PLAN_PRICES:
        raise HTTPException(status_code=400, detail="Invalid plan")

    price_usd = PLAN_PRICES[body.plan]["USD"]
    order = await paypal_request("post", "/v2/checkout/orders", {
        "intent": "CAPTURE",
        "purchase_units": [{
            "amount": {"currency_code": "USD", "value": str(price_usd)},
            "description": f"JADWAL {body.plan.title()} — Monthly Subscription",
            "custom_id": f"{current_user['business_id']}|{body.plan}",
        }],
        "application_context": {
            "return_url": f"{settings.FRONTEND_URL}/payment/success",
            "cancel_url":  f"{settings.FRONTEND_URL}/payment/cancel",
        }
    })

    approval_url = next(
        (link["href"] for link in order.get("links", []) if link["rel"] == "approve"),
        None
    )
    return {"order_id": order["id"], "approval_url": approval_url}


# ── CAPTURE PAYPAL PAYMENT ────────────────────────────────────────────────────
class CaptureRequest(BaseModel):
    order_id: str
    plan: str

@router.post("/paypal/capture")
async def capture_paypal(
    body: CaptureRequest,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    capture = await paypal_request("post", f"/v2/checkout/orders/{body.order_id}/capture")

    if capture.get("status") != "COMPLETED":
        raise HTTPException(status_code=400, detail="Payment not completed")

    amount = float(capture["purchase_units"][0]["payments"]["captures"][0]["amount"]["value"])
    txn_id = capture["id"]

    # Record payment
    await db.execute(
        """INSERT INTO payments (business_id, provider, provider_txn_id, amount, currency, plan, status, webhook_data)
           VALUES ($1, 'paypal', $2, $3, 'USD', $4, 'completed', $5)""",
        uuid.UUID(current_user["business_id"]), txn_id,
        amount, body.plan, json.dumps(capture)
    )

    # Upgrade plan
    await db.execute(
        """UPDATE businesses SET plan = $1, plan_started_at = NOW(),
           paypal_subscription_id = $2
           WHERE id = $3""",
        body.plan, txn_id, uuid.UUID(current_user["business_id"])
    )

    await send_payment_confirmation(current_user["email"], body.plan, amount, "USD")
    await log_action(db, uuid.UUID(current_user["business_id"]),
                     uuid.UUID(current_user["id"]),
                     "payment.completed", "payment", None,
                     {"plan": body.plan, "amount": amount, "provider": "paypal"})

    return {"message": f"Upgraded to {body.plan}", "plan": body.plan}


# ── ZIINA (UAE LOCAL PAYMENT) ─────────────────────────────────────────────────
class ZiinaRequest(BaseModel):
    plan: str
    currency: str = "AED"

@router.post("/ziina/create")
async def create_ziina_payment(
    body: ZiinaRequest,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    if body.plan not in PLAN_PRICES:
        raise HTTPException(status_code=400, detail="Invalid plan")

    price = PLAN_PRICES[body.plan][body.currency]
    amount_fils = price * 100   # Ziina uses smallest currency unit

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            "https://api-v2.ziina.com/api/payment_intent",
            headers={
                "Authorization": f"Bearer {settings.ZIINA_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "amount": amount_fils,
                "currency_code": body.currency,
                "message": f"JADWAL {body.plan.title()} Subscription",
                "success_url": f"{settings.FRONTEND_URL}/payment/success",
                "cancel_url":  f"{settings.FRONTEND_URL}/payment/cancel",
                "test": settings.ENVIRONMENT != "production",
            }
        )

    data = resp.json()
    if resp.status_code != 200:
        raise HTTPException(status_code=502, detail="Ziina payment creation failed")

    return {
        "payment_url": data.get("redirect_url"),
        "payment_id": data.get("id"),
    }


# ── PAYPAL WEBHOOK ────────────────────────────────────────────────────────────
@router.post("/paypal-webhook")
async def paypal_webhook(request: Request, db=Depends(get_db)):
    body = await request.body()
    event = json.loads(body)

    # TODO: Verify webhook signature with PayPal verify API
    event_type = event.get("event_type", "")

    if event_type == "PAYMENT.CAPTURE.COMPLETED":
        txn_id = event["resource"]["id"]
        custom_id = event["resource"]["purchase_units"][0].get("custom_id", "")

        if "|" in custom_id:
            business_id, plan = custom_id.split("|", 1)
            await db.execute(
                "UPDATE businesses SET plan = $1, plan_started_at = NOW() WHERE id = $2",
                plan, uuid.UUID(business_id)
            )
            logger.info(f"PayPal webhook: upgraded {business_id} to {plan}")

    elif event_type == "BILLING.SUBSCRIPTION.CANCELLED":
        # Downgrade to trial or free when subscription cancelled
        txn_id = event["resource"]["id"]
        await db.execute(
            "UPDATE businesses SET plan = 'trial' WHERE paypal_subscription_id = $1",
            txn_id
        )

    return {"received": True}


# ── ZIINA WEBHOOK ─────────────────────────────────────────────────────────────
@router.post("/ziina-webhook")
async def ziina_webhook(
    request: Request,
    x_ziina_signature: Optional[str] = Header(None),
    db=Depends(get_db)
):
    body = await request.body()

    # Verify signature
    if x_ziina_signature and settings.ZIINA_WEBHOOK_SECRET:
        expected = hmac.new(
            settings.ZIINA_WEBHOOK_SECRET.encode(),
            body, hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(expected, x_ziina_signature):
            raise HTTPException(status_code=401, detail="Invalid webhook signature")

    event = json.loads(body)
    if event.get("status") == "COMPLETED":
        # Extract business_id from metadata if set
        metadata = event.get("metadata", {})
        business_id = metadata.get("business_id")
        plan = metadata.get("plan")

        if business_id and plan:
            await db.execute(
                "UPDATE businesses SET plan = $1, plan_started_at = NOW() WHERE id = $2",
                plan, uuid.UUID(business_id)
            )
            logger.info(f"Ziina webhook: upgraded {business_id} to {plan}")

    return {"received": True}


# ── PAYMENT STATUS ────────────────────────────────────────────────────────────
@router.get("/status")
async def payment_status(
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db)
):
    biz = await db.fetchrow(
        "SELECT plan, plan_started_at, trial_ends_at FROM businesses WHERE id = $1",
        uuid.UUID(current_user["business_id"])
    )
    payments = await db.fetch(
        """SELECT provider, amount, currency, plan, status, created_at
           FROM payments WHERE business_id = $1 ORDER BY created_at DESC LIMIT 10""",
        uuid.UUID(current_user["business_id"])
    )
    return {
        "current_plan": biz["plan"],
        "plan_started_at": biz["plan_started_at"],
        "trial_ends_at": biz["trial_ends_at"],
        "payment_history": [dict(p) for p in payments]
    }
