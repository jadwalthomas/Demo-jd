"""
JADWAL — WhatsApp Service via 360Dialog
"""

import httpx
import logging
import os

logger = logging.getLogger(__name__)
DIALOG_KEY = os.getenv("DIALOG360_API_KEY", "")
DIALOG_URL = "https://waba.360dialog.io/v1/messages"


async def send_whatsapp(phone: str, message: str) -> bool:
    """Send a WhatsApp message via 360Dialog API."""
    if not DIALOG_KEY:
        logger.warning("360Dialog key not set — WhatsApp not sent")
        return False

    # Normalize phone — remove spaces, ensure + prefix
    phone = phone.replace(" ", "").replace("-", "")
    if not phone.startswith("+"):
        phone = "+" + phone

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.post(
                DIALOG_URL,
                headers={"D360-API-KEY": DIALOG_KEY, "Content-Type": "application/json"},
                json={
                    "messaging_product": "whatsapp",
                    "to": phone,
                    "type": "text",
                    "text": {"body": message}
                }
            )
            if resp.status_code == 200:
                return True
            else:
                logger.error(f"360Dialog error {resp.status_code}: {resp.text[:200]}")
                return False
    except Exception as e:
        logger.error(f"WhatsApp send error: {e}")
        return False
