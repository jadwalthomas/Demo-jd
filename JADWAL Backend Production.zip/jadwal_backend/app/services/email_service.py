"""
JADWAL — Email Service
Uses Resend (resend.com) — best deliverability, works perfectly from UAE
"""

import httpx
import logging
from app.config import settings

logger = logging.getLogger(__name__)

RESEND_API = "https://api.resend.com/emails"
HEADERS = {
    "Authorization": f"Bearer {settings.RESEND_API_KEY}",
    "Content-Type": "application/json",
}


async def _send(to: str, subject: str, html: str) -> bool:
    """Internal send helper."""
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(RESEND_API, headers=HEADERS, json={
                "from": f"{settings.FROM_NAME} <{settings.FROM_EMAIL}>",
                "to": [to],
                "subject": subject,
                "html": html,
            })
            if resp.status_code == 200:
                return True
            else:
                logger.error(f"Resend error {resp.status_code}: {resp.text}")
                return False
    except Exception as e:
        logger.error(f"Email send error: {e}")
        return False


# ── WELCOME EMAIL ─────────────────────────────────────────────────────────────
async def send_welcome_email(email: str, name: str, business_name: str) -> bool:
    html = f"""
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;background:#07070d;color:#eeeae0;border-radius:16px;overflow:hidden">
      <div style="background:linear-gradient(135deg,#c9a84c,#7a6230);padding:28px;text-align:center">
        <h1 style="margin:0;font-size:28px;letter-spacing:4px;color:#000">JADWAL</h1>
        <p style="margin:6px 0 0;font-size:12px;color:#1a1400">جدول · UAE AI Workforce Platform</p>
      </div>
      <div style="padding:32px">
        <h2 style="color:#e8c878;margin-top:0">Welcome to JADWAL, {name}! 🇦🇪</h2>
        <p style="color:#9090a8;line-height:1.7">
          Your account for <strong style="color:#eeeae0">{business_name}</strong> is ready.
          You have a <strong style="color:#c9a84c">30-day free trial</strong> with full access
          to all features — AI scheduling, Emiratisation tracking, WPS export, HR automation, and more.
        </p>
        <div style="background:#111118;border-radius:12px;padding:20px;margin:24px 0;border:1px solid #1c1c2e">
          <p style="margin:0 0 12px;font-weight:700;color:#c9a84c">Get started in 3 steps:</p>
          <p style="margin:6px 0;color:#9090a8">1. Add your employees (Settings → Employees)</p>
          <p style="margin:6px 0;color:#9090a8">2. Click Generate — AI builds your first schedule</p>
          <p style="margin:6px 0;color:#9090a8">3. Publish — every employee gets a WhatsApp automatically</p>
        </div>
        <a href="{settings.FRONTEND_URL}" style="display:inline-block;background:linear-gradient(135deg,#c9a84c,#7a6230);color:#000;text-decoration:none;padding:13px 28px;border-radius:10px;font-weight:700;margin-top:8px">Open JADWAL →</a>
      </div>
      <div style="padding:20px;text-align:center;border-top:1px solid #1c1c2e">
        <p style="margin:0;font-size:11px;color:#5a5a72">
          JADWAL Technologies LLC · Meydan Free Zone, Dubai, UAE<br>
          +971 55 466 0881 · jadwal.ae
        </p>
      </div>
    </div>
    """
    return await _send(email, "Welcome to JADWAL 🇦🇪 — Your UAE Workforce Platform", html)


# ── PAYMENT CONFIRMATION ──────────────────────────────────────────────────────
async def send_payment_confirmation(
    email: str, plan: str, amount: float, currency: str
) -> bool:
    html = f"""
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;background:#07070d;color:#eeeae0;border-radius:16px;overflow:hidden">
      <div style="background:linear-gradient(135deg,#c9a84c,#7a6230);padding:28px;text-align:center">
        <h1 style="margin:0;font-size:28px;letter-spacing:4px;color:#000">JADWAL</h1>
      </div>
      <div style="padding:32px">
        <h2 style="color:#00c48c;margin-top:0">✓ Payment Confirmed</h2>
        <div style="background:#111118;border-radius:12px;padding:20px;border:1px solid #00c48c40">
          <p style="margin:4px 0;color:#9090a8">Plan: <strong style="color:#eeeae0">{plan.title()}</strong></p>
          <p style="margin:4px 0;color:#9090a8">Amount: <strong style="color:#c9a84c">{currency} {amount:.2f}</strong></p>
          <p style="margin:4px 0;color:#9090a8">Status: <strong style="color:#00c48c">Active</strong></p>
        </div>
        <p style="color:#9090a8;margin-top:20px;line-height:1.7">
          Your subscription is now active. All premium features are unlocked.
          Thank you for choosing JADWAL. 🇦🇪
        </p>
        <a href="{settings.FRONTEND_URL}" style="display:inline-block;background:linear-gradient(135deg,#c9a84c,#7a6230);color:#000;text-decoration:none;padding:13px 28px;border-radius:10px;font-weight:700">Open JADWAL →</a>
      </div>
    </div>
    """
    return await _send(email, f"✓ JADWAL {plan.title()} — Payment Confirmed", html)


# ── SCHEDULE REPORT EMAIL ─────────────────────────────────────────────────────
async def send_schedule_report(
    email: str, business_name: str, week_start: str,
    employee_count: int, hr_alerts: list
) -> bool:
    alert_html = ""
    if hr_alerts:
        items = "".join([
            f'<li style="color:#ff4560">{a["employee"]}: {", ".join(a["issues"])}</li>'
            for a in hr_alerts
        ])
        alert_html = f"""
        <div style="background:#3d0010;border-radius:10px;padding:16px;margin:16px 0;border:1px solid #ff456040">
          <p style="margin:0 0 8px;font-weight:700;color:#ff4560">⚠ HR Alerts ({len(hr_alerts)} employees)</p>
          <ul style="margin:0;padding-left:18px">{items}</ul>
          <p style="margin:8px 0 0;font-size:11px;color:#9090a8">These employees have HR issues. Go to HR Automation to resolve.</p>
        </div>
        """

    html = f"""
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;background:#07070d;color:#eeeae0;border-radius:16px;overflow:hidden">
      <div style="background:linear-gradient(135deg,#c9a84c,#7a6230);padding:20px;text-align:center">
        <h1 style="margin:0;font-size:24px;letter-spacing:3px;color:#000">JADWAL</h1>
      </div>
      <div style="padding:28px">
        <h2 style="color:#e8c878;margin-top:0">📅 Schedule Published — {week_start}</h2>
        <p style="color:#9090a8">{business_name}</p>
        <div style="background:#111118;border-radius:10px;padding:16px;border:1px solid #1c1c2e">
          <p style="margin:4px 0;color:#9090a8">Employees scheduled: <strong style="color:#eeeae0">{employee_count}</strong></p>
          <p style="margin:4px 0;color:#9090a8">WhatsApp notifications: <strong style="color:#25D366">Sent ✓</strong></p>
          <p style="margin:4px 0;color:#9090a8">HR alerts: <strong style="color:{'#ff4560' if hr_alerts else '#00c48c'}">{len(hr_alerts) if hr_alerts else 'None ✓'}</strong></p>
        </div>
        {alert_html}
        <a href="{settings.FRONTEND_URL}/schedule" style="display:inline-block;background:linear-gradient(135deg,#c9a84c,#7a6230);color:#000;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:700;margin-top:16px">View Schedule →</a>
      </div>
    </div>
    """
    return await _send(email, f"📅 JADWAL — Schedule Published for week of {week_start}", html)


# ── VISA EXPIRY ALERT ─────────────────────────────────────────────────────────
async def send_visa_alert(
    email: str, employee_name: str, days_remaining: int, expiry_date: str
) -> bool:
    urgency = "🔴 EXPIRED" if days_remaining < 0 else f"🟠 {days_remaining} days remaining"
    html = f"""
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto;background:#07070d;color:#eeeae0;border-radius:16px;overflow:hidden">
      <div style="background:#3d0010;padding:20px;text-align:center">
        <h1 style="margin:0;font-size:20px;color:#ff4560">🛂 Visa Alert — Action Required</h1>
      </div>
      <div style="padding:28px">
        <h2 style="color:#ff4560;margin-top:0">{urgency}</h2>
        <div style="background:#111118;border-radius:10px;padding:16px;border:1px solid #ff456040">
          <p style="margin:4px 0;color:#9090a8">Employee: <strong style="color:#eeeae0">{employee_name}</strong></p>
          <p style="margin:4px 0;color:#9090a8">Visa Expiry: <strong style="color:#ff4560">{expiry_date}</strong></p>
          <p style="margin:4px 0;color:#9090a8">Status: <strong style="color:#ff4560">{urgency}</strong></p>
        </div>
        <p style="color:#9090a8;margin-top:16px;line-height:1.7">
          Go to HR Automation → Work Permits to initiate the renewal process via the MOHRE eServices portal.
        </p>
        <a href="{settings.FRONTEND_URL}/hr" style="display:inline-block;background:#ff4560;color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:700;margin-top:12px">Go to HR Automation →</a>
      </div>
    </div>
    """
    return await _send(email, f"🛂 JADWAL Visa Alert — {employee_name} · {urgency}", html)
