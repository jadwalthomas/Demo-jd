# audit_service.py
"""Audit logging — every action recorded with who, what, when."""

import uuid
import json


async def log_action(db, business_id, user_id, action: str,
                     entity_type: str = None, entity_id=None,
                     details: dict = None):
    try:
        await db.execute(
            """INSERT INTO audit_log
               (business_id, user_id, action, entity_type, entity_id, details)
               VALUES ($1, $2, $3, $4, $5, $6)""",
            business_id, user_id, action, entity_type,
            entity_id, json.dumps(details or {})
        )
    except Exception:
        pass  # Never let audit logging break the main flow
