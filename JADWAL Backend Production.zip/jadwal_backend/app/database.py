"""
JADWAL — Database Connection
Uses Supabase Python client + asyncpg for direct SQL queries
"""

from supabase import create_client, Client
from app.config import settings
import asyncpg
import logging

logger = logging.getLogger(__name__)

# Supabase client (for Storage, Auth helpers)
supabase: Client = create_client(
    settings.SUPABASE_URL,
    settings.SUPABASE_SERVICE_KEY   # Service key — server-side only
)

# Connection pool for direct SQL (faster for complex queries)
_pool = None

async def get_pool():
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(
            settings.DATABASE_URL,
            min_size=2,
            max_size=10,
            command_timeout=30,
        )
    return _pool

async def get_db():
    """FastAPI dependency — yields a database connection."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        yield conn

async def close_pool():
    global _pool
    if _pool:
        await _pool.close()
        _pool = None
