"""
JADWAL - Production FastAPI Backend
UAE AI Workforce Scheduling Platform
Thomas Tamrat Goshu | JADWAL Technologies LLC | Dubai, UAE
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging

from app.routes import auth, employees, schedule, hr, payments, files, webhooks, compliance
from app.routes.webhooks import start_scheduler, stop_scheduler
from app.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="JADWAL API",
    description="UAE AI Workforce Scheduling Platform — Production Backend",
    version="1.0.0",
    docs_url="/docs" if settings.ENVIRONMENT != "production" else None,
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router,        prefix="/api/auth",       tags=["Auth"])
app.include_router(employees.router,   prefix="/api/employees",  tags=["Employees"])
app.include_router(schedule.router,    prefix="/api/schedule",   tags=["Schedule"])
app.include_router(hr.router,          prefix="/api/hr",         tags=["HR"])
app.include_router(payments.router,    prefix="/api/payments",   tags=["Payments"])
app.include_router(files.router,       prefix="/api/files",      tags=["Files"])
app.include_router(compliance.router,  prefix="/api/compliance", tags=["Compliance"])

@app.on_event("startup")
async def startup():
    start_scheduler()
    logger.info("JADWAL API started — scheduler running")

@app.on_event("shutdown")
async def shutdown():
    stop_scheduler()
    from app.database import close_pool
    await close_pool()

@app.get("/")
async def root():
    return {"status": "JADWAL API running", "version": "1.0.0", "region": "UAE"}

@app.get("/health")
async def health():
    return {"status": "healthy"}
