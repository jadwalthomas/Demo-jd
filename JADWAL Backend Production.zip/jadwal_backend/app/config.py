"""
JADWAL Configuration — All settings loaded from environment variables
Never hardcode secrets. Everything lives in .env (local) or Railway env vars (production).
"""

from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    # ── App ────────────────────────────────────────────────────────────────
    APP_NAME: str = "JADWAL"
    ENVIRONMENT: str = "development"   # development | production
    API_BASE_URL: str = "http://localhost:8000"
    FRONTEND_URL: str = "http://localhost:3000"

    # ── Supabase (Database + Auth + Storage) ───────────────────────────────
    SUPABASE_URL: str
    SUPABASE_ANON_KEY: str
    SUPABASE_SERVICE_KEY: str          # Server-side only — never sent to browser
    DATABASE_URL: str                  # postgres://... from Supabase

    # ── JWT ───────────────────────────────────────────────────────────────
    JWT_SECRET: str                    # Generate: openssl rand -hex 32
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 60 * 24 * 7   # 7 days

    # ── Anthropic — NEVER sent to browser ─────────────────────────────────
    ANTHROPIC_API_KEY: str

    # ── Email (Resend — best for UAE + global) ─────────────────────────────
    RESEND_API_KEY: str
    FROM_EMAIL: str = "noreply@jadwal.ae"
    FROM_NAME: str = "JADWAL"

    # ── Payments ──────────────────────────────────────────────────────────
    PAYPAL_CLIENT_ID: str
    PAYPAL_CLIENT_SECRET: str
    PAYPAL_WEBHOOK_ID: str
    PAYPAL_MODE: str = "sandbox"       # sandbox | live

    ZIINA_API_KEY: str
    ZIINA_WEBHOOK_SECRET: str

    # ── File Storage (Supabase Storage) ───────────────────────────────────
    STORAGE_BUCKET: str = "jadwal-documents"
    MAX_FILE_SIZE_MB: int = 10

    # ── CORS ──────────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "https://jadwal.ae",
        "https://www.jadwal.ae",
        "https://app.jadwal.ae",
    ]

    # ── UAE Compliance ────────────────────────────────────────────────────
    EMIRATISATION_FINE_PER_MONTH: int = 7000
    PROBATION_DAYS: int = 180
    VISA_ALERT_DAYS: List[int] = [90, 30, 7]

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
