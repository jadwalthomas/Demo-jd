-- ============================================================
-- JADWAL — Supabase Database Schema
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor)
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── BUSINESSES ────────────────────────────────────────────────────────────
CREATE TABLE businesses (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id        UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    name_ar         TEXT,
    business_type   TEXT NOT NULL DEFAULT 'Retail Store',
    phone           TEXT,
    email           TEXT,
    trade_license   TEXT,
    meydan_fz_no    TEXT,

    -- Subscription
    plan            TEXT NOT NULL DEFAULT 'trial',  -- trial | starter | growth | enterprise
    plan_started_at TIMESTAMPTZ,
    trial_ends_at   TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '30 days'),
    stripe_customer_id TEXT,
    paypal_subscription_id TEXT,
    ziina_customer_id TEXT,

    -- Settings stored as JSONB
    workflow_settings JSONB DEFAULT '{
        "blockScheduleOnMissingDocs": false,
        "alertHROnMissingDocs": true,
        "autoHRChecklistOnNewEmp": true,
        "notifyHROnNewEmp": true,
        "autoWhatsAppOnPublish": true,
        "warnProbationExpiry": true,
        "autoEOSAlert": true,
        "leaveAutoDeduct": true
    }'::jsonb,

    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── EMPLOYEES ─────────────────────────────────────────────────────────────
CREATE TABLE employees (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id     UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

    -- Personal
    name            TEXT NOT NULL,
    name_ar         TEXT,
    role            TEXT NOT NULL,
    phone           TEXT NOT NULL,
    email           TEXT,
    nationality     TEXT NOT NULL DEFAULT 'Emirati',
    emirates_id     TEXT,

    -- Employment
    salary          NUMERIC(10,2) DEFAULT 0,
    basic_salary    NUMERIC(10,2) GENERATED ALWAYS AS (salary * 0.6) STORED,
    max_hours_week  INT DEFAULT 40,
    join_date       DATE,
    active          BOOLEAN DEFAULT TRUE,

    -- Visa & Permits
    visa_expiry     DATE,
    permit_number   TEXT,
    permit_expiry   DATE,

    -- Leave balances
    annual_leave_days   INT DEFAULT 30,
    annual_leave_used   INT DEFAULT 0,
    sick_leave_days     INT DEFAULT 60,
    sick_leave_used     INT DEFAULT 0,

    -- HR Status
    hr_status       TEXT DEFAULT 'pending',  -- pending | ready | flagged
    onboarding_done BOOLEAN DEFAULT FALSE,

    -- Documents checklist (stored as JSONB)
    documents       JSONB DEFAULT '{
        "passport": false,
        "emirates_id": false,
        "visa_copy": false,
        "employment_contract": false,
        "medical_certificate": false
    }'::jsonb,

    -- Onboarding checklist
    onboarding      JSONB DEFAULT '{
        "contract_signed": false,
        "mohre_applied": false,
        "contract_registered": false,
        "medical_done": false,
        "wps_activated": false,
        "emirates_id_issued": false,
        "insurance_added": false
    }'::jsonb,

    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── SCHEDULES ─────────────────────────────────────────────────────────────
CREATE TABLE schedules (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id     UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    created_by      UUID REFERENCES auth.users(id),

    week_start      DATE NOT NULL,
    business_type   TEXT,
    published       BOOLEAN DEFAULT FALSE,
    published_at    TIMESTAMPTZ,
    wa_sent         BOOLEAN DEFAULT FALSE,
    wa_sent_at      TIMESTAMPTZ,

    -- Full AI-generated schedule data
    schedule_data   JSONB NOT NULL DEFAULT '[]',

    -- Metadata
    hr_alerts       JSONB DEFAULT '[]',   -- employees with HR issues at generation time
    ai_model        TEXT DEFAULT 'claude-sonnet-4-20250514',
    generation_ms   INT,                  -- how long AI took in ms

    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── SHIFTS (individual rows per employee per day) ─────────────────────────
CREATE TABLE shifts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    schedule_id     UUID NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
    employee_id     UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    business_id     UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

    shift_date      DATE NOT NULL,
    shift_type      TEXT,   -- Morning | Afternoon | Night | OFF
    start_time      TIME,
    end_time        TIME,
    hours           NUMERIC(4,1),
    is_off          BOOLEAN DEFAULT FALSE,

    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── LEAVE REQUESTS ────────────────────────────────────────────────────────
CREATE TABLE leave_requests (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id     UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    employee_id     UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,

    leave_type      TEXT NOT NULL,   -- annual | sick | unpaid | hajj | maternity
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    days            INT NOT NULL,
    reason          TEXT,
    status          TEXT DEFAULT 'approved',  -- pending | approved | rejected
    recorded_by     UUID REFERENCES auth.users(id),

    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── DOCUMENTS (file metadata) ─────────────────────────────────────────────
CREATE TABLE employee_documents (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id     UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    business_id     UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

    doc_type        TEXT NOT NULL,    -- passport | emirates_id | visa_copy | contract | medical
    file_name       TEXT NOT NULL,
    storage_path    TEXT NOT NULL,    -- Supabase Storage path
    file_size_kb    INT,
    mime_type       TEXT,
    uploaded_by     UUID REFERENCES auth.users(id),
    expires_at      DATE,             -- for visa/permit docs

    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── NOTIFICATIONS / WHATSAPP LOG ──────────────────────────────────────────
CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id     UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    employee_id     UUID REFERENCES employees(id) ON DELETE SET NULL,
    schedule_id     UUID REFERENCES schedules(id) ON DELETE SET NULL,

    type            TEXT NOT NULL,    -- schedule | hr_alert | visa_alert | probation | eos
    recipient_name  TEXT,
    recipient_phone TEXT,
    message         TEXT NOT NULL,
    channel         TEXT DEFAULT 'whatsapp',
    delivered       BOOLEAN DEFAULT FALSE,
    read            BOOLEAN DEFAULT FALSE,
    is_owner        BOOLEAN DEFAULT FALSE,

    sent_at         TIMESTAMPTZ DEFAULT NOW()
);

-- ── PAYMENTS ──────────────────────────────────────────────────────────────
CREATE TABLE payments (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id     UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,

    provider        TEXT NOT NULL,    -- paypal | ziina | manual
    provider_txn_id TEXT,
    amount          NUMERIC(10,2) NOT NULL,
    currency        TEXT DEFAULT 'AED',
    plan            TEXT NOT NULL,
    status          TEXT DEFAULT 'pending',  -- pending | completed | failed | refunded
    webhook_data    JSONB,

    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── AUDIT LOG ────────────────────────────────────────────────────────────
CREATE TABLE audit_log (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id     UUID REFERENCES businesses(id) ON DELETE SET NULL,
    user_id         UUID REFERENCES auth.users(id) ON DELETE SET NULL,

    action          TEXT NOT NULL,    -- employee.created | schedule.published | payment.completed etc.
    entity_type     TEXT,             -- employee | schedule | payment | document
    entity_id       UUID,
    details         JSONB,
    ip_address      TEXT,

    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── INDEXES ───────────────────────────────────────────────────────────────
CREATE INDEX idx_employees_business    ON employees(business_id);
CREATE INDEX idx_employees_active      ON employees(business_id, active);
CREATE INDEX idx_schedules_business    ON schedules(business_id);
CREATE INDEX idx_shifts_schedule       ON shifts(schedule_id);
CREATE INDEX idx_shifts_employee       ON shifts(employee_id);
CREATE INDEX idx_notifications_biz     ON notifications(business_id);
CREATE INDEX idx_audit_business        ON audit_log(business_id);
CREATE INDEX idx_audit_user            ON audit_log(user_id);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────────────────
-- Businesses can only see their own data
ALTER TABLE employees           ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedules           ENABLE ROW LEVEL SECURITY;
ALTER TABLE shifts               ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_requests      ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_documents  ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications        ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments            ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log           ENABLE ROW LEVEL SECURITY;

-- Policy: users can only access their own business's data
CREATE POLICY "business_isolation" ON employees
    USING (business_id IN (
        SELECT id FROM businesses WHERE owner_id = auth.uid()
    ));

CREATE POLICY "business_isolation" ON schedules
    USING (business_id IN (
        SELECT id FROM businesses WHERE owner_id = auth.uid()
    ));

-- Repeat for all tables (same pattern)
CREATE POLICY "business_isolation" ON shifts
    USING (business_id IN (SELECT id FROM businesses WHERE owner_id = auth.uid()));
CREATE POLICY "business_isolation" ON leave_requests
    USING (business_id IN (SELECT id FROM businesses WHERE owner_id = auth.uid()));
CREATE POLICY "business_isolation" ON employee_documents
    USING (business_id IN (SELECT id FROM businesses WHERE owner_id = auth.uid()));
CREATE POLICY "business_isolation" ON notifications
    USING (business_id IN (SELECT id FROM businesses WHERE owner_id = auth.uid()));
CREATE POLICY "business_isolation" ON payments
    USING (business_id IN (SELECT id FROM businesses WHERE owner_id = auth.uid()));

-- ── UPDATED_AT TRIGGER ────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ language 'plpgsql';

CREATE TRIGGER set_updated_at BEFORE UPDATE ON businesses
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON employees
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
